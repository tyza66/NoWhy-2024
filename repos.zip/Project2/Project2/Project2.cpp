﻿#include <xmlrpc-c/base.hpp>
#include <xmlrpc-c/registry.hpp>
#include <xmlrpc-c/server_abyss.hpp>

#include<iostream>
using namespace std;

class sampleAddMethod : public xmlrpc_c::method {
public:
    sampleAddMethod() {
        this->_signature = "i:ii";
        this->_help = "This method adds two integers together";
    }
    void execute(xmlrpc_c::paramList const& paramList, xmlrpc_c::value* const  retvalP) {
        cout << "有过程调用进来了" << endl;
        int const addend(paramList.getInt(0));
        int const adder(paramList.getInt(1));
        cout << "参数1:" << addend  << endl;
        cout << "参数2:" << adder << endl;
        paramList.verifyEnd(2);
        *retvalP = xmlrpc_c::value_int(addend + adder);
    }
};

int main(int const, const char** const) {
    try {
        xmlrpc_c::registry myRegistry;
        xmlrpc_c::methodPtr const sampleAddMethodP(new sampleAddMethod);
        myRegistry.addMethod("sample.add", sampleAddMethodP);
        xmlrpc_c::serverAbyss myAbyssServer(
            xmlrpc_c::serverAbyss::constrOpt()
            .registryP(&myRegistry)
            .portNumber(8000));
        cout << "XmlRpc服务端已正常启动" << endl;
        myAbyssServer.run();
    }
    catch (std::exception const& e) {
        cout << "XmlRpc服务端发生异常" << endl;
    }
    return 0;
}
